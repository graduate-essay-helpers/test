<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GraduateEssayHelpers | Discount Coupon</title>
</head>

<body>
    <h3>Hello <?php $name ?>,</h3><br />
    <h4>We are greatful to have you as one of our clients on our <a href="https://graduate-essay-helpers.com">site</a>. Here is a discount coupon for your next order.</h4>
    <h4>Coupon Code: <?php $gen_coupon ?></h4>
    <h4>Valid until: <?php $expiration_date ?></h4>
    <br />
    <h4>Have a great day!</h4>
</body>

</html>