<?php
	$conn = mysqli_connect('localhost:3307', 'root', '', 'db_coupon');
	
	if(!$conn){
		die("Error: Failed to connect to database");
	}
