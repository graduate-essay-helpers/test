<?php
require_once '../admin/conn.php';
if (isset($_POST['save'])) {
	$coupon_code = $_POST['coupon'];
	$discount = $_POST['discount'];
	$status = "Valid";
	$query = mysqli_query($con, "SELECT * FROM `coupon` WHERE `coupon_code` = '$coupon_code'");
	$row = mysqli_num_rows($query);

	if ($row > 0) {
		echo "<script>alert('Coupon Already Use')</script>";
		echo "<script>window.location = 'index.php'</script>";
	} else {
		mysqli_query($con, "INSERT INTO `coupon` VALUES('', '$coupon_code', '$discount', '$status')");
		echo "<script>alert('Coupon Saved!')</script>";
		echo "<script>window.location = 'index.php'</script>";
	}
}
