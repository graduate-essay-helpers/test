<?php
// session_start();
if ($_SESSION['id'] == '') {
    header('location: https://graduate-essay-helpers.com/orders.php');
}
// $_SESSION['id'] = '';

$id = $_SESSION['id'];
