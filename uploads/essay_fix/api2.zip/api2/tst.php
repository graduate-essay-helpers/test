<?php
echo "This is a test text...";
