<div class="ops-form-group row">
    <label class="ops-sm-3" for="ops_aclevel"> Academic level </label>
    <div class="ops-sm-9">

        <div class="row opclick btn-group" data-toggle="buttons">
            <label class="ops-sm-3 btn btn-default">
                <input type="radio" name="ops_aclevel" class="form-control custom-select border-default ops-sm-8" id="ops_aclevel" value="0.91#
                                                            High School">
                High School </input>
            </label>
            <label class="ops-sm-3 btn btn-default">
                <input type="radio" name="ops_aclevel" class="form-control custom-select border-default ops-sm-8" id="ops_aclevel" value="1#
                                                            College">
                College </input>
            </label>
            <label class="ops-sm-3 btn btn-default">
                <input type="radio" name="ops_aclevel" class="form-control custom-select border-default ops-sm-8" id="ops_aclevel" value="1.15#
                                                            Undergraduate">
                Undergraduate </input>
            </label>
            <label class="ops-sm-3 btn btn-default">
                <input type="radio" name="ops_aclevel" class="form-control custom-select border-default ops-sm-8" id="ops_aclevel" value="1.2#
                                                            Masters">
                Masters </input>
            </label>
            <label class="ops-sm-3 btn btn-default">
                <input type="radio" name="ops_aclevel" class="form-control custom-select border-default ops-sm-8" id="ops_aclevel" value="1.3#
                                                            PHD">
                PHD </input>
            </label>
        </div>
    </div>
</div>