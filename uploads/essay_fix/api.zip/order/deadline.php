<div class="ops-form-group opclick row lg-deadline">
    <label class="ops-lg-3"> Deadline </label>
    <div class="ops-lg-8 btn-group">
        <div class="row buttoncente" data-toggle="buttons">

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="27.4#6 Hours" name="order_deadline">6 Hours
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="27#8 Hours" name="order_deadline">8 Hours
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="26.56#12 Hours" name="order_deadline">12 Hours
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="25.5#18 Hours" name="order_deadline">18 Hours
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="23.73#24 Hours" name="order_deadline">24 Hours
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="22.24#48 Hours" name="order_deadline">48 Hours
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="20.54#3 Days" name="order_deadline">3 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="19#4 Days" name="order_deadline">4 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="17#5 Days" name="order_deadline">5 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="16#6 Days" name="order_deadline">6 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="14.75#7 Days" name="order_deadline">7 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="14#10 Days" name="order_deadline">10 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="12.75#12 Days" name="order_deadline">12 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="12.55#15 Days" name="order_deadline">15 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="12.35#20 Days" name="order_deadline">20 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="12.22#30 Days" name="order_deadline">30 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="12#60 Days" name="order_deadline">60 Days
            </label>

            <label class="btn btn-default ops-sm-2 ">
                <input type="radio" id="a1" value="11.78#90 Days" name="order_deadline">90 Days
            </label>



        </div>

    </div>

</div>

<div class="ops-form-group row mobile-deadline mobile-deadline">
    <label class="ops-sm-3"> Deadline </label>

    <select class="form-control ops-sm-8 custom-select border-default" id="a1" name="order_deadline">
        <option value="5 hours 59 minutes 59 seconds" selected="selected">6 Hours</option>
        <option value="7 hours 59 minutes 59 seconds">8 Hours</option>
        <option value="11 hours 59 minutes 59 seconds">12 Hours</option>
        <option value="17 hours 59 minutes 59 seconds">18 Hours</option>
        <option value="23 hours 59 minutes 59 seconds">24 Hours</option>
        <option value="47 hours 59 minutes 59 seconds">48 Hours</option>
        <option value="20.54#3 Days">3 Days</option>
        <option value="19#4 Days">4 Days</option>
        <option value="17#5 Days">5 Days</option>
        <option value="16#6 Days">6 Days</option>
        <option value="14.75#7 Days">7 Days</option>
        <option value="14#10 Days">10 Days</option>
        <option value="12.75#12 Days">12 Days</option>
        <option value="12.55#15 Days">15 Days</option>
        <option value="12.35#20 Days">20 Days</option>
        <option value="12.22#30 Days">30 Days</option>
        <option value="12#60 Days">60 Days</option>
        <option value="11.78#90 Days">90 Days</option>
    </select>


</div>