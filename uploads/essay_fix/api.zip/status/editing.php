<?php
include "../admin/conn.php";
include "../admin/auth.php";
include "../admin/pg_auth.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login/Register | GraduateEssayHelpers</title>
    <meta name="description" content="Register today and get not just Only a quality paper, but also 0% plagiarism.">
    <meta name="author" content="">

    <!-- Bootstrap core CSS -->
    <link href="../order_assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha512-SfTiTlX6kk+qitfevl/7LibUOeJWlt9rbyDn92a1DqWOw9vWG2MFoays0sgObmWazO5BQPiFucnnEAjpAB+/Sw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Custom styles for this template -->
    <link href="../order_assets/css/opskill-styles.css" rel="stylesheet">
    <link href="../order_assets/css/header-style-eleven.css" rel="stylesheet">
    <script src="../order_assets/js/bootstrap/jquery.sidr.min.js"></script>
    <script src="../order_assets/js/bootstrap/jquery.min.js"></script>
    <script src="../order_assets/js/bootstrap/bootstrap.min.js"></script>
    <script src="../order_assets/js/bootstrap/megamenu.js"></script>

</head>

<!doctype html>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">


    <script src="./order_assets/js/webfont.js"></script>

    <link rel='stylesheet' id='opskill-css' href='../order_assets/css/opskill-css.css' type='text/css' media='all' />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha512-SfTiTlX6kk+qitfevl/7LibUOeJWlt9rbyDn92a1DqWOw9vWG2MFoays0sgObmWazO5BQPiFucnnEAjpAB+/Sw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel='stylesheet' id='wp-block-library-css' href='../order_assets/css/block-library-css.css' type='text/css' media='all' />
    <link rel='stylesheet' id='rt-megamenu-front-end-style-css' href='../order_assets/css/megamenu-front.css' type='text/css' media='all' />
    <link rel='stylesheet' id='rs-plugin-settings-css' href='../order_assets/css/plugin-settings-css.css' type='text/css' media='all' />

    <link rel='stylesheet' id='bootstrap-css' href='../order_assets/css/bootstrap-css.css' type='text/css' media='all' />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel='stylesheet' id='animate-css' href='../order_assets/css/animate.css' type='text/css' media='all' />
    <link rel='stylesheet' id='radiantthemes-custom-css' href='../order_assets/css/rt/custom.css' type='text/css' media='all' />
    <link rel='stylesheet' id='radiantthemes-responsive-css' href='../order_assets/css/rt/responsive.css' type='text/css' media='all' />
    <link rel='stylesheet' id='radiantthemes-header-style-eleven-css' href='../order_assets/css/rt/style-eleven.css' type='text/css' media='all' />
    <link rel='stylesheet' id='radiantthemes-footer-style-one-css' href='../order_assets/css/rt/footer-style-one.css' type='text/css' media='all' />
    <link rel='stylesheet' id='radiantthemes-user-custom-css' href='../order_assets/css/rt/user-custom.css' type='text/css' media='all' />
    <link rel='stylesheet' id='radiantthemes-dynamic-css' href='../order_assets/css/rt/dynamic-css.css' type='text/css' media='all' />
    <link rel='stylesheet' id='radiantthemes-button-element-one-css' href='../order_assets/css/rt/button-element.css' type='text/css' media='all' />

    <script type='text/javascript' src='../order_assets/js/jquery.js'></script>
    <script type='text/javascript' src='../order_assets/js/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='../order_assets/js/jquery.themepunch.tools.min.js'></script>
    <script type='text/javascript' src='../order_assets/js/jquery.themepunch.revolution.min.js'></script>
    <script type='text/javascript' src='../order_assets/js/retina.min.js'></script>

    <script type='text/javascript' src='../js/mega-menu.js'></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sidr/2.2.1/jquery.sidr.min.js" integrity="sha512-HvecYeVgMOaHjNBv7DnIvCpVb7ad5FPEhnU/PMhp41YTcgNymgOKfsVioe/9QaeCnadAeoL9ZxEhaHtWN8Sc9Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- <link rel='https://api.w.org/' href='https://akademicwriters.com/wp-json/' /> -->
    <!-- <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://akademicwriters.com/xmlrpc.php?rsd" /> -->
    <!-- <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://akademicwriters.com/wp-includes/wlwmanifest.xml" /> -->
    <script src="./order_assets/js/setStartSize.js"></script>
    <link rel="stylesheet" href="../order_assets/css/custom-css.css">
    <link rel="stylesheet" href="../order_assets/css/dynamic-css.css">
    <noscript>
        <style>
            .wpb_animate_when_almost_visible {
                opacity: 1;
            }
        </style>
    </noscript>
    <style>
        @media screen and (max-width: 455px) {
            /* .navbar-light {
                background: red;
            } */

            .opskillheader {
                position: relative;
                right: 25%;
                z-index: 0;
            }
        }

        .lg-deadline {
            display: none;
        }

        @media screen and (min-width: 1440px) {
            .mobile-deadline {
                display: none;
            }

            .lg-deadline {
                display: block;
            }
        }

        @media screen and (min-width: 1024px) {
            .mobile-deadline {
                display: none;
            }

            .lg-deadline {
                display: block;
            }
        }

        @media screen and (min-width: 768px) {
            .mobile-deadline {
                display: none;
            }

            .lg-deadline {
                display: block;
            }
        }
    </style>
</head>



<body class="hfeed wpb-js-composer js-comp-ver-6.0.3 vc_responsive" data-header-style="header-style-eleven" data-nicescroll-cursorcolor="#ffbc13" data-nicescroll-cursorwidth="7px">



    <!-- overlay -->
    <div class="overlay"></div>
    <!-- overlay -->

    <!-- scrollup -->
    <div class="scrollup left">
        <i class="fa fa-angle-up"></i>
    </div>
    <!-- scrollup -->


    <!-- radiantthemes-website-layout -->
    <div class="radiantthemes-website-layout full-width">


        <?php include "../header/nav.php" ?>

        <!-- wraper_header_bannerinner -->
        <div class="wraper_inner_banner">
            <!-- wraper_inner_banner_main -->
            <div class="wraper_inner_banner_main">
                <div class="container">
                    <!-- row -->
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <!-- inner_banner_main -->
                            <div class="inner_banner_main">
                                <p class="title">
                                    Graduate Essay Helpers </p>
                                <p class="subtitle">
                                    Academic and Essay Writing Service </p>
                            </div>
                            <!-- inner_banner_main -->
                        </div>
                    </div>
                    <!-- row -->
                </div>
            </div>
            <!-- wraper_inner_banner_main -->
            <!-- wraper_inner_banner_breadcrumb -->
            <div class="wraper_inner_banner_breadcrumb">
                <div class="container">
                    <!-- row -->
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <!-- inner_banner_breadcrumb -->
                            <div class="inner_banner_breadcrumb">
                                <div id="crumbs"><a href="https://graduate-essay-helpers.com">Home</a> <span class="gap"><i class="el el-chevron-right"></i></span> <span class="current"></span></div>
                            </div>
                            <!-- inner_banner_breadcrumb -->
                        </div>
                    </div>
                    <!-- row -->
                </div>
            </div>
            <!-- wraper_inner_banner_breadcrumb -->
        </div>
        <!-- wraper_header_bannerinner -->
        <!-- wraper_header_bannerinner -->


        <!-- #page -->
        <div id="page" class="site">
            <!-- #content -->
            <div id="content" class="site-content">

                <?php include "../user/loggedin_user-profile.php" ?>


                <section class="orders features orderview" id="">
                    <div class="container">
                        <br />
                        <?php include "./../order/status.php" ?>
                        <hr />

                        <?php

                        $user_id = $_SESSION['id'];

                        $order = "SELECT * FROM orders WHERE user_id = $user_id AND order_status = 'editing' ORDER BY id DESC";
                        $result = mysqli_query($con, $order);
                        // $row = mysqli_fetch_assoc($result);

                        $sql = mysqli_query($con, "SELECT * FROM payments");
                        $qry = mysqli_fetch_array($sql);
                        $ord = $qry['ord_id'];
                        $sts = $qry['status'];
                        $amt = $qry['amount'];
                        ?>

                        <div class="row">

                            <div class="ops-sm-1">ID</div>
                            <div class="ops-sm-2">Topic/Title</div>
                            <div class="ops-sm-2">Due Time</div>
                            <div class="ops-sm-2">Status</div>
                            <div class="ops-sm-1"> Writer</div>
                            <div class="ops-sm-2">Pay</div>
                            <div class="ops-sm-2"></div>
                        </div>
                        <hr />

                        <div class="orderlib">



                            <?php while ($fetch = mysqli_fetch_array($result)) {
                                $id_ord = $fetch['id'];

                                $sql = mysqli_query($con, "SELECT status FROM payments WHERE ord_id = $id_ord");
                                $qry = mysqli_fetch_array($sql);
                                $sts = $qry[0];
                            ?>
                                <div class="row">
                                    <div class="ops-sm-1">#<?php echo $fetch['id'] ?></div>
                                    <div class="ops-sm-2">
                                        <a href="./../order/order-checkout.php?id=<?php echo $fetch['id'] ?>"> <?php echo $fetch['title'] ?> </a>
                                    </div>
                                    <div class="ops-sm-2">


                                        <?php echo $fetch['deadline'] ?>
                                    </div>

                                    <?php
                                    $mnt = $fetch['total'];
                                    if ($sts == "PENDING") {
                                    ?>
                                        <div class="ops-sm-2">paid</div>
                                    <?php
                                    } else {
                                    ?>
                                        <div class="ops-sm-2">bidding || unpayments</div>
                                    <?php
                                    }
                                    ?>



                                    <div class="ops-sm-1 text-center">0</div>
                                    <div class="ops-sm-2">

                                        <?php
                                        // $ord_id = $fetch['id'];
                                        // echo $ord_id;
                                        // $sql = mysqli_query($con, "SELECT * FROM payments WHERE ord_id = $ord_id");
                                        // $qry = mysqli_fetch_array($sql);
                                        // $sts = $qry['ord_id'];
                                        // echo $sts;
                                        ?>

                                        <?php
                                        $mnt = $fetch['total'];
                                        if ($sts == "PENDING") {
                                            echo "paid $$mnt";
                                        ?>
                                        <?php
                                        } else {
                                        ?>
                                            <!-- Button trigger modal -->

                                            <button type="button" class="btn ops-sm-12 text-white btn-warning" data-toggle="modal" data-target="#<?php echo $fetch['id'] ?>">
                                                Pay ($<?php echo $fetch['total'] ?>)
                                            </button>
                                        <?php
                                        }
                                        ?>

                                    </div>

                                    <!-- ======================================================================= -->


                                    <div class="ops-sm-2">

                                        <?php
                                        // $ord_id = $fetch['id'];
                                        // echo $ord_id;
                                        // $sql = mysqli_query($con, "SELECT * FROM payments WHERE ord_id = $ord_id");
                                        // $qry = mysqli_fetch_array($sql);
                                        // $sts = $qry['ord_id'];
                                        // echo $sts;
                                        ?>

                                        <?php
                                        if ($sts == "PENDING") {
                                        ?>
                                            <!-- Button trigger modal -->

                                            <button type="button" class="btn ops-sm-12 text-white btn-warning" data-toggle="modal" data-target="#<?php echo $fetch['id'] ?>">
                                                Payment Details
                                            </button>
                                        <?php
                                        } else {
                                        ?>
                                        <?php
                                        }
                                        ?>


                                        <?php
                                        $mnt = $fetch['total'];
                                        if ($sts == "PENDING") {
                                        ?>
                                            <!-- Modal -->
                                            <div class="modal fade" id="<?php echo $fetch['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Order #<?php echo $fetch['id'] ?></h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">


                                                            <div class="row text-center">
                                                                <div class="col">
                                                                    <h6> View details for your order</h6>
                                                                    <hr />
                                                                    <a class="btn ops-sm-12 btn-danger text-white" href="../order/choose-payment.php?id=<?php echo $fetch['id'] ?>">Payment </a>
                                                                </div>

                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php
                                        } else {
                                        ?>
                                            <!-- Modal -->
                                            <div class="modal fade" id="<?php echo $fetch['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Pay Order #<?php echo $fetch['id'] ?></h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">


                                                            <div class="row text-center">
                                                                <div class="col">
                                                                    <h6> Pay for your order</h6>
                                                                    <hr />
                                                                    <a class="btn ops-sm-12 btn-danger text-white" href="../order/choose-payment.php?id=<?php echo $fetch['id'] ?>">Pay ($<?php echo $fetch['total'] ?>) </a>
                                                                </div>

                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php
                                        }
                                        ?>

                                    </div>
                                </div>
                            <?php
                            }
                            ?>


                        </div>
                        <hr />
                        <div class="pagination float-right">
                            <li></li>
                        </div>







                </section>
            </div>