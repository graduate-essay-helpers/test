<?php
require 'db_conn.php';
$data = json_decode(file_get_contents("php://input"));
// if (
//     isset($data->userids)
//     && !empty(trim($data->userids))
// ) {
// $adduserid = mysqli_real_escape_string($db_conn, trim($data->userids));
$allOrders = mysqli_query($db_conn, "SELECT * FROM orders");
if (mysqli_num_rows($allOrders) > 0) {
    while ($row = mysqli_fetch_array($allOrders)) {
        $viewjson["id"] = $row['id'];
        $viewjson["user_id"] = $row['user_id'];
        $viewjson["academic_level"] = $row['academic_level'];
        $viewjson["deadline"] = $row['deadline'];
        $viewjson["coupon_code"] = $row['coupon_code'];
        $viewjson["total"] = $row['total'];
        $viewjson["order_status"] = $row['order_status'];
        $viewjson["payment_status"] = $row['payment_status'];
        $viewjson["created_at"] = $row['created_at'];
        $json_array["orderdata"][] = $viewjson;
    }
    echo json_encode(["success" => true, "orderlist" => $json_array]);
    return;
} else {
    echo json_encode(["success" => false]);
    return;
}
// }
